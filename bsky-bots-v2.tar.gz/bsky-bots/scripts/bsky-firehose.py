#!/usr/bin/env python3
from bskybots.services.firehose_listener import main
if __name__ == "__main__":
    main()
