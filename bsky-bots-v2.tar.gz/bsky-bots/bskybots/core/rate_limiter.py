import time
from collections import deque

class RateLimiter:
    def __init__(self, max_events: int, window_seconds: int):
        self.max_events = max_events
        self.window = window_seconds
        self.events = deque()

    def allow(self) -> bool:
        now = time.time()
        while self.events and now - self.events[0] > self.window:
            self.events.popleft()
        if len(self.events) < self.max_events:
            self.events.append(now)
            return True
        return False
