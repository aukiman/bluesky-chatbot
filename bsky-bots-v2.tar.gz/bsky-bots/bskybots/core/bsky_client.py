from typing import Optional
from atproto import Client, models
from .utils import now_iso

class BskyClient:
    def __init__(self, handle: str, app_password: str):
        self.client = Client()
        self.profile = self.client.login(handle, app_password)
        self.handle = handle

    def list_mentions_and_replies(self, limit: int = 50):
        params = models.AppBskyNotificationListNotifications.Params(limit=limit, reasons=["mention","reply"])
        res = self.client.app.bsky.notification.list_notifications(params=params)
        return res.notifications

    def mark_notifications_seen(self):
        data = models.AppBskyNotificationUpdateSeen.Data(seen_at=now_iso())
        self.client.app.bsky.notification.update_seen(data)

    def search_posts(self, query: str, since: Optional[str] = None, limit: int = 30):
        params = models.AppBskyFeedSearchPosts.Params(q=query, limit=limit)
        if since:
            params.since = since
        return self.client.app.bsky.feed.search_posts(params).posts

    def get_post(self, uri: str):
        return self.client.get_post(uri)

    def get_reply_ref(self, uri: str):
        post = self.client.get_post(uri)
        parent_ref = models.create_strong_ref(post)
        # root
        try:
            thread = self.client.app.bsky.feed.get_post_thread(models.AppBskyFeedGetPostThread.Params(uri=uri, depth=0))
            root_post = getattr(thread.thread, "post", post)
        except Exception:
            root_post = post
        root_ref = models.create_strong_ref(root_post)
        return models.AppBskyFeedPost.ReplyRef(parent=parent_ref, root=root_ref)

    def send_reply(self, text: str, parent_uri: str):
        reply_ref = self.get_reply_ref(parent_uri)
        return self.client.send_post(text=text, reply_to=reply_ref, langs=["en"])
