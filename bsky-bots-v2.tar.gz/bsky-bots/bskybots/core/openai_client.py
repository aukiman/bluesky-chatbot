import os, json
from tenacity import retry, stop_after_attempt, wait_exponential_jitter

class OpenAIClient:
    def __init__(self, model: str = "gpt-4o-mini", temperature: float = 0.7, system_prompt: str | None = None):
        from openai import OpenAI
        api_key = os.environ.get("OPENAI_API_KEY")
        if not api_key:
            raise RuntimeError("OPENAI_API_KEY is not set")
        self.client = OpenAI(api_key=api_key)
        self.model = model
        self.temperature = temperature
        self.system_prompt = system_prompt or "You are a helpful assistant."

    @retry(stop=stop_after_attempt(3), wait=wait_exponential_jitter(min=1, max=10))
    def classify_and_generate(self, *, text: str, author: str, nsfw_allowed: bool, persona: dict, thread_context: dict | None = None, target_lang: str = "en"):
        messages = [
            {"role":"system","content": self.system_prompt},
            {"role":"user","content": json.dumps({
                "post_text": text,
                "author": author,
                "nsfw_allowed": nsfw_allowed,
                "target_lang": target_lang,
                "persona": persona,
                "thread_context": thread_context or {}
            })}
        ]
        r = self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            temperature=self.temperature,
            max_tokens=180
        )
        out = r.choices[0].message.content
        try:
            data = json.loads(out)
        except Exception:
            data = {"should_reply": False, "reply": ""}
        return data
