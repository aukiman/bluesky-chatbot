import re
from typing import List, Dict
from .utils import looks_political, looks_nsfw

def hashtags(text: str) -> List[str]:
    return re.findall(r"#(\w+)", text or "")

def allow_post(text: str, author: str, *, allow_unprompted: bool, nsfw_allowed: bool, allow: Dict, block: Dict) -> bool:
    if looks_political(text):
        return False
    if looks_nsfw(text) and not nsfw_allowed:
        return False

    # Block lists
    if author and author.lower() in [u.lower() for u in block.get("users", [])]:
        return False
    low = (text or "").lower()
    for p in block.get("phrases", []):
        if p.lower() in low:
            return False
    hset = set([h.lower() for h in hashtags(text)])
    if hset & set([h.lower().lstrip('#') for h in block.get("hashtags", [])]):
        return False

    # Allow lists (if provided, require match of at least one)
    has_allow = any(block_list for block_list in [allow.get("users"), allow.get("phrases"), allow.get("hashtags")])
    if has_allow:
        if author and allow.get("users") and author.lower() in [u.lower() for u in allow.get("users", [])]:
            pass
        elif any(p.lower() in low for p in allow.get("phrases", [])):
            pass
        elif hset & set([h.lower().lstrip('#') for h in allow.get("hashtags", [])]):
            pass
        else:
            return False

    return allow_unprompted
