import re
import time
import hashlib
from datetime import datetime, timezone
from typing import Iterable, Dict, Any

POLITICAL_KEYWORDS = [
    "election","senate","parliament","congress","prime minister","president",
    "vote","voting","left-wing","right-wing","liberal","conservative","labor",
    "greens","republican","democrat","policy","campaign","mp ","senator","minister",
    "referendum","brexit","tax policy","immigration policy"
]

NSFW_KEYWORDS = [
    "nsfw","adult","sex","sext","explicit","nude","porn","xxx","onlyfans"
]

def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()

def sha1(text: str) -> str:
    return hashlib.sha1(text.encode("utf-8")).hexdigest()

def looks_political(text: str) -> bool:
    t = text.lower()
    return any(k in t for k in POLITICAL_KEYWORDS)

def looks_nsfw(text: str) -> bool:
    t = text.lower()
    return any(k in t for k in NSFW_KEYWORDS)

def backoff_sleep(attempt: int, base: float = 1.5, cap: float = 60.0) -> None:
    delay = min(cap, base ** attempt)
    time.sleep(delay)

def clamp(n: int, a: int, b: int) -> int:
    return max(a, min(n, b))

def chunks(it: Iterable, n: int):
    it = iter(it)
    while True:
        batch = []
        try:
            for _ in range(n):
                batch.append(next(it))
        except StopIteration:
            pass
        if not batch:
            break
        yield batch

def score_text(text: str, keywords: Iterable[str]) -> int:
    t = text.lower()
    score = 0
    for kw in keywords:
        if kw.lower() in t:
            score += 5
    score += min(3, len(t)//140)  # longer posts get a tiny extra
    return score

def apply_persona(reply: str, persona: Dict[str, Any]) -> str:
    # Light touch adjustments only
    tone = persona.get("tone","warm")
    humour = int(persona.get("humour",1))
    emoji_density = int(persona.get("emoji_density",1))
    formality = int(persona.get("formality",1))
    # formality adjustment
    if formality == 0:
        reply = reply.replace("do not","don't").replace("cannot","can't")
    elif formality >= 2:
        reply = reply.replace("don't","do not").replace("can't","cannot")
    # humour & emoji
    emojis = ["🙂","😄","✨","🤘","🎶","🔥","👍","🙌"]
    if emoji_density > 0:
        reply = reply + " " + " ".join(emojis[:emoji_density])
    return reply.strip()
