import argparse, logging, yaml, sys
from pathlib import Path
from .worker_bot import BotWorker
from ..core import store

def load_yaml(fp: str):
    with open(fp, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def main():
    parser = argparse.ArgumentParser(description="Run Bluesky bots.")
    parser.add_argument("--config", "-c", default="/etc/bsky-bots/bots.yaml", help="Path to bots.yaml")
    parser.add_argument("--global-config", "-g", default="/etc/bsky-bots/global.yaml", help="Path to global.yaml")
    parser.add_argument("--prompt", "-p", default="/opt/bsky-bots/prompts/system_prompt.txt", help="Path to system prompt")
    parser.add_argument("--once", action="store_true", help="Run a single pass instead of a loop")
    args = parser.parse_args()

    Path("/var/lib/bsky-bots").mkdir(parents=True, exist_ok=True)
    Path("/var/log/bsky-bots").mkdir(parents=True, exist_ok=True)
    store.init_db()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
        handlers=[
            logging.FileHandler("/var/log/bsky-bots/bots.log"),
            logging.StreamHandler(sys.stdout)
        ]
    )

    bots_cfg = load_yaml(args.config)
    global_cfg = load_yaml(args.global_config)

    workers = [BotWorker(bot, global_cfg, args.prompt) for bot in bots_cfg.get("bots", [])]

    if not workers:
        logging.error("No bots configured. Edit %s", args.config)
        sys.exit(1)

    if args.once:
        for w in workers:
            w.run_once()
    else:
        while True:
            for w in workers:
                w.run_once()

if __name__ == "__main__":
    main()
